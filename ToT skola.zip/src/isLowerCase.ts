export function isLowerCase(input: string): boolean {
    return input === input.toLowerCase();
  }
